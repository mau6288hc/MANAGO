package customadapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.lab06.R;

import java.util.ArrayList;
import java.util.List;

import model.Product;
import model.ProductDAO;

/**
 * Created by hai to on 4/13/2018.
 */

public class CustomAdapter  extends BaseAdapter{
    ArrayList<Product> productDAOArrayList;
    Context context;
    LayoutInflater layoutInflater;

    public CustomAdapter(ArrayList<Product> productDAOArrayList, Context context, LayoutInflater layoutInflater) {
        this.productDAOArrayList = productDAOArrayList;
        this.context = context;
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount() {
        return productDAOArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.customlistview,null);
        ImageView imageView = view.findViewById(R.id.ProImage);
        TextView name = view.findViewById(R.id.ProName);
        TextView price = view.findViewById(R.id.ProPrice);

        byte[] image = productDAOArrayList.get(i).getImage();
        Bitmap myimage = BitmapFactory.decodeByteArray(image, 0, image.length);
        imageView.setImageBitmap(myimage);
        name.setText(productDAOArrayList.get(i).getName());
        price.setText(productDAOArrayList.get(i).getPrice()+"");
        return view;
    }
}
