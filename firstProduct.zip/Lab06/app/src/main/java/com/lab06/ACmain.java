package com.lab06;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

import customadapter.CustomAdapter;
import model.Product;
import model.ProductDAO;
import sqlite.DatabaseHelper;

public class ACmain extends AppCompatActivity {
    EditText edtname, edtPrice;
    Button chooseImage, btnAdd, btnDialogSave,btnDialogUpdate,btnDelete;
    ImageView ProImage;
    byte[] myimage;
    ListView mylistView;
    ProductDAO dao;
    CustomAdapter adapter;
    DatabaseHelper helper;
    ArrayList<Product> productList;
    public static final int REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

       //PERMISSION IN AndroidManifest <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"></uses-permission>
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acmain);

        // SHOW LISTVIEW
        mylistView = findViewById(R.id.Prolistview);
        helper = new DatabaseHelper(getApplicationContext());
        dao = new ProductDAO(helper,adapter);
        productList = new ArrayList<>();
        productList = dao.getAllProduct();
        adapter = new CustomAdapter(productList,getApplicationContext(), LayoutInflater.from(getApplicationContext()));
        mylistView.setAdapter(adapter);


        // ADD PRODUCT
        btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // TURN ADD_SAVE PRODUCT DIALOG
                AlertDialog.Builder builder = new AlertDialog.Builder(ACmain.this);
                View viewDialog = getLayoutInflater().inflate(R.layout.dialog, null);

                builder.setView(viewDialog);
                AlertDialog dialog = builder.create();
                dialog.show();

                // GET ELEMENT ON LAYOUT
                edtname = viewDialog.findViewById(R.id.etDialogName);
                edtPrice = viewDialog.findViewById(R.id.etDialogPrice);
                chooseImage = viewDialog.findViewById(R.id.btnChooseImage);
                ProImage = viewDialog.findViewById(R.id.DialogProImage);
                btnDialogSave = viewDialog.findViewById(R.id.btnDialogSave);
                // BUTTON CHOOSE IMAGE ON DIALOG
                chooseImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_PICK);
                        intent.setType("image/*");
                        startActivityForResult(intent, REQUEST_CODE);
                    }
                });
                // BUTTON SAVE_PRODUCT ON DIALOG
                btnDialogSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        // SET , NAME, PRICE, BITMAP_IMAGE_ID,
                        Product product = new Product();
                        product.setName(edtname.getText() + "");
                        product.setImage(myimage);
                        product.setPrice(Integer.parseInt(edtPrice.getText() + ""));

                        // CALL METHOD INSERT_PRODUCT
                        helper = new DatabaseHelper(getApplicationContext());
                        dao = new ProductDAO(helper,adapter);
                        long result = dao.insertProduct(product);
                        if (result < 0)
                            Toast.makeText(getApplicationContext(), "Add Erro", Toast.LENGTH_SHORT).show();
                        else {
                            Toast.makeText(getApplicationContext(), "Add Successfully", Toast.LENGTH_SHORT).show();
                            productList.add(product);
                            adapter.notifyDataSetChanged();
                        }
                    }
                });

            }
        });


        // EVENT CLICK ITEM ON LISTVIEW
        mylistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int position, long id) {

                // TURN DIALOG_CHOOSE
                AlertDialog.Builder builder = new AlertDialog.Builder(ACmain.this);
                View viewDialog = getLayoutInflater().inflate(R.layout.dialog_choose, null);

                builder.setView(viewDialog);
                AlertDialog dialog = builder.create();
                dialog.show();

                // BUTTON DELETE_PRODUCT ON DIALOG
                btnDelete = viewDialog.findViewById(R.id.btnDialogDelete);
                btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        // CALL METHOD DELETE_PRODUCT
                        helper = new DatabaseHelper(getApplicationContext());
                        dao = new ProductDAO(helper,adapter);
                        int result = dao.deleteProduct(position);
                        if (result < 0)
                            Toast.makeText(getApplicationContext(), "Delete Erro", Toast.LENGTH_SHORT).show();
                        else {
                            Toast.makeText(getApplicationContext(), "Delete Successfully", Toast.LENGTH_SHORT).show();
                            productList.remove(position);
                            adapter.notifyDataSetChanged();
                        }
                    }
                });

                // BUTTON UPDATE_PRODUCT ON DIALOG
                btnDialogUpdate = viewDialog.findViewById(R.id.btnDialogUpdate);
                btnDialogUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // TURN UPDATE_SAVE PRODUCT DIALOG
                        AlertDialog.Builder builder = new AlertDialog.Builder(ACmain.this);
                        View viewDialog = getLayoutInflater().inflate(R.layout.dialog, null);

                        builder.setView(viewDialog);
                        final AlertDialog dialog = builder.create();
                        dialog.show();

                        // GET ELEMENT ON LAYOUT
                        edtname = viewDialog.findViewById(R.id.etDialogName);
                        edtPrice = viewDialog.findViewById(R.id.etDialogPrice);
                        chooseImage = viewDialog.findViewById(R.id.btnChooseImage);
                        ProImage = viewDialog.findViewById(R.id.DialogProImage);
                        btnDialogSave = viewDialog.findViewById(R.id.btnDialogSave);

                        // BUTTON CHOOSE IMAGE ON DIALOG
                        chooseImage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent intent = new Intent(Intent.ACTION_PICK);
                                intent.setType("image/*");
                                startActivityForResult(intent, REQUEST_CODE);
                            }
                        });

                        // BUTTON SAVE_PRODUCT ON DIALOG
                        btnDialogSave.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                // SET , NAME, PRICE, BITMAP_IMAGE_ID,
                                Product product = new Product();
                                product.setId(position);
                                product.setName(edtname.getText() + "");
                                product.setImage(myimage);
                                product.setPrice(Integer.parseInt(edtPrice.getText() + ""));

                                // CALL METHOD INSERT_PRODUCT
                                helper = new DatabaseHelper(getApplicationContext());
                                dao = new ProductDAO(helper,adapter);
                                int result = dao.updateProduct(product);
                                if (result < 0)
                                    Toast.makeText(getApplicationContext(), "Update Erro", Toast.LENGTH_SHORT).show();
                                else {
                                    Toast.makeText(getApplicationContext(), "Update Successfully", Toast.LENGTH_SHORT).show();
                                    productList.set(position,product);
                                    adapter.notifyDataSetChanged();
                                    dialog.dismiss();
                                }
                            }
                        });
                    }
                });
            }
        });

    }

    // METHOD GET IMAGE FROM GALLERY
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Make sure the request was successful
        if (resultCode == RESULT_OK) {

            // Check which request it is that we're responding to
            if (requestCode == REQUEST_CODE) {
                // Get the URI that points to the selected contact
                final Uri imageUri = data.getData();
                InputStream imageStream = null;
                try {
                    imageStream = getContentResolver().openInputStream(imageUri);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

                ProImage.setImageBitmap(selectedImage);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                selectedImage.compress(Bitmap.CompressFormat.PNG, 0, stream);
                myimage = stream.toByteArray();

            }
        }
    }

}
