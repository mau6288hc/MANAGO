package model;

/**
 * Created by hai to on 4/13/2018.
 */

public class Product {
    int id;
    String name;
    int price;
    byte[] image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Product(int id, String name, int price, byte[] image) {

        this.id = id;
        this.name = name;
        this.price = price;
        this.image = image;
    }

    public Product() {

    }
}
