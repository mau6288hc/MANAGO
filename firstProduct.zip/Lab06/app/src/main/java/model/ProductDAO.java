package model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.LayoutInflater;

import com.lab06.ACmain;

import java.util.ArrayList;
import java.util.List;

import customadapter.CustomAdapter;
import sqlite.DatabaseHelper;

/**
 * Created by hai to on 4/13/2018.
 */

public class ProductDAO {
    DatabaseHelper helper;
    CustomAdapter adapter;

    public ProductDAO(DatabaseHelper helper, CustomAdapter adapter) {
        this.helper = helper;
        this.adapter = adapter;
    }

    public static final String TABLE_NAME = "PRODUCT";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_IMAGE = "IMAGE";
    public static final String COLUMN_NAME = "NAME";
    public static final String COLUMN_PRICE = "PRICE";

    public static final String CREATE_TABLE = "CREATE TABLE "+ TABLE_NAME +" ( "
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_IMAGE + " BLOB,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_PRICE + " INTEGER )";
    public static final String SELECT_ALL = " SELECT * FROM " + TABLE_NAME;

    // INSERT PRODUCT
    public long insertProduct(Product product){
        SQLiteDatabase db = helper.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME,product.getName());
        values.put(COLUMN_IMAGE,product.getImage());
        values.put(COLUMN_PRICE,product.getPrice());

        long position = db.insert(TABLE_NAME,null,values);
        db.close();
        return position;
    }
// GET ALL

    public ArrayList<Product> getAllProduct(){
        ArrayList<Product> productList = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery(SELECT_ALL,null);
        if(cursor.moveToFirst()){
            do {
                Product product = new Product();
                product.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
                product.setImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_IMAGE)));
                product.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                product.setPrice(cursor.getInt(cursor.getColumnIndex(COLUMN_PRICE)));

                productList.add(product);
            }while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return productList;
    }
    // UPDATE PRODUCT
    public int updateProduct(Product product){
        SQLiteDatabase db = helper.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME,product.getName());
        values.put(COLUMN_IMAGE,product.getImage());
        values.put(COLUMN_PRICE,product.getPrice());

        int row=db.update(TABLE_NAME,values,COLUMN_ID + "=?", new String[]{product.getId()+""});
        db.close();
        return row;
    }
    // DELETE PRODUCT
    public int deleteProduct(int id){
        SQLiteDatabase db = helper.getReadableDatabase();
        int row = db.delete(TABLE_NAME,COLUMN_ID + "=?",new String[]{id+""});
        return row;
    }

}

